# ToiletPaper

This is a prototype of a program to compare supermarket products by calculating comparable values from the product declarations.
The first product is toilet paper.
