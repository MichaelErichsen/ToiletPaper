# ToiletPaper

This is a prototype of a program to compare supermarket products by calculating comparable values from the product declarations.
The first product is toilet paper.

Release 0.1.0 has been released for end user test by May 6th 2020.
