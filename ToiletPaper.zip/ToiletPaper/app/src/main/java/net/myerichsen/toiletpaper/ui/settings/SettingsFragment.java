package net.myerichsen.toiletpaper.ui.settings;
/*
 * Copyright (c) 2020. Michael Erichsen.
 */

import android.os.Bundle;
import android.view.View;

import androidx.preference.DropDownPreference;
import androidx.preference.Preference;
import androidx.preference.PreferenceFragmentCompat;
import androidx.preference.SwitchPreferenceCompat;

import com.google.android.material.snackbar.Snackbar;

import net.myerichsen.toiletpaper.R;
import net.myerichsen.toiletpaper.TPDbAdapter;
import net.myerichsen.toiletpaper.ui.suppliers.SupplierModel;

import java.util.List;
import java.util.Objects;

public class SettingsFragment extends PreferenceFragmentCompat {
    private Snackbar snackbar;
    private View snackView;

    @Override
    public void onCreatePreferences(Bundle savedInstanceState, String rootKey) {
        snackView = requireActivity().findViewById(android.R.id.content);
        setPreferencesFromResource(R.xml.preferences, rootKey);

        try {
            TPDbAdapter adapter = new TPDbAdapter(getContext());

            // TODO Implement simple and advanced screens
            SwitchPreferenceCompat advancedScreenPreference = findPreference("advancedscreen");
            Objects.requireNonNull(advancedScreenPreference).setOnPreferenceChangeListener(advancedScreenOnPreferenceChangeListener());

            Preference initialLoadPreference = findPreference("initialload");
            Objects.requireNonNull(initialLoadPreference).setOnPreferenceClickListener(initLoadOnClickListener(adapter));

            DropDownPreference fontSizePreference = findPreference("fontsize");
            Objects.requireNonNull(fontSizePreference).setOnPreferenceClickListener(fontSizeOnPreferenceClickListener());

            DropDownPreference defaultSupplierPreference = findPreference("defaultsupplier");

            populateSupplierDropDown(adapter, defaultSupplierPreference);

            Objects.requireNonNull(defaultSupplierPreference).setOnPreferenceClickListener(defaultSupplierOnClickListener());
        } catch (Exception e) {
            snackbar = Snackbar
                    .make(snackView, Objects.requireNonNull(e.getMessage()), Snackbar.LENGTH_LONG);
            snackbar.show();
        }
    }

    private void populateSupplierDropDown(TPDbAdapter adapter, DropDownPreference defaultSupplierPreference) {
        List<SupplierModel> lsm;
        SupplierModel sm;

        try {
            lsm = adapter.getSupplierModels();
        } catch (Exception e) {
            Snackbar snackbar = Snackbar
                    .make(snackView, Objects.requireNonNull(e.getMessage()), Snackbar.LENGTH_LONG);
            snackbar.show();
            return;
        }

        int count = lsm.size();

        if (count == 0) {
            Snackbar snackbar = Snackbar
                    .make(snackView, "No data in table", Snackbar.LENGTH_LONG);
            snackbar.show();
            return;
        }

        String[] entries = new String[count];
        String[] entryValues = new String[count];

        for (int i = 0; i < count; i++) {
            sm = lsm.get(i);
            entries[i] = sm.getSupplier();
            entryValues[i] = sm.getSupplier();
        }

        defaultSupplierPreference.setEntries(entries);
        defaultSupplierPreference.setEntryValues(entryValues);
    }

    private Preference.OnPreferenceChangeListener advancedScreenOnPreferenceChangeListener() {
        return new Preference.OnPreferenceChangeListener() {
            @Override
            public boolean onPreferenceChange(Preference preference, Object newValue) {
                return false;
            }
        };
    }

    private Preference.OnPreferenceClickListener defaultSupplierOnClickListener() {
        return new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                try {
                    DropDownPreference dropDownPreference = (DropDownPreference) preference;
                    String key = dropDownPreference.getValue();
                    // FIXME Not quite OK
                    dropDownPreference.setSummary(key);
                    return true;
                } catch (Exception e) {
                    snackbar = Snackbar
                            .make(snackView, Objects.requireNonNull(e.getMessage()), Snackbar.LENGTH_LONG);
                    snackbar.show();
                    return false;
                }
            }
        };
    }

    private Preference.OnPreferenceClickListener fontSizeOnPreferenceClickListener() {
        return new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                try {
                    DropDownPreference dropDownPreference = (DropDownPreference) preference;
                    String key = dropDownPreference.getValue();
                    // FIXME Not quite OK
                    dropDownPreference.setSummary(key);
                    return true;
                } catch (Exception e) {
                    snackbar = Snackbar
                            .make(snackView, Objects.requireNonNull(e.getMessage()), Snackbar.LENGTH_LONG);
                    snackbar.show();
                    return false;
                }
            }
        };
    }

    private Preference.OnPreferenceClickListener initLoadOnClickListener(final TPDbAdapter adapter) {
        return new Preference.OnPreferenceClickListener() {
            @Override
            public boolean onPreferenceClick(Preference preference) {
                try {
                    adapter.doInitialLoad();
                    snackbar = Snackbar
                            .make(snackView, R.string.initial_load_done, Snackbar.LENGTH_LONG);
                    snackbar.show();
                    return true;
                } catch (Exception e) {
                    snackbar = Snackbar
                            .make(snackView, Objects.requireNonNull(e.getMessage()), Snackbar.LENGTH_LONG);
                    snackbar.show();
                    return false;
                }
            }
        };
    }
//    public class supplierDropDownPreference extends DropDownPreference {
//
//    }
}
